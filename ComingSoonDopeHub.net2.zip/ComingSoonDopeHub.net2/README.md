# ComingSoonDopeHub.net

DopeHub coming-soon website, redesigned 2 October 2026.

The current design uses an ivory editorial layout, a botanical photograph that
opens full-screen and settles into an arch, and compact signup and volunteer
dialogs. Existing signup preferences, applications and privacy copy are retained.

Current design files: `site/index.html`, `site/editorial.css`, `site/editorial.js`.
Previous page and scripts: `preview/design-before-editorial/` (the previous
stylesheets remain in `site/`). Screenshots: `preview/editorial-desktop.jpg`
and `preview/editorial-390.jpg`.

Double-click **Open Preview.cmd**, keep its window open, then visit:
http://127.0.0.1:8775/

Requires Python 3, already installed on this computer.

Static view: http://127.0.0.1:8775/?motion=still
Local email previews: http://127.0.0.1:8775/__mail/

- site/: complete website, animation, fonts, logo, artwork and admin interface.
- server/: signup/application backend and example configuration.
- tools/: local preview and email campaign helper.
- tests/: backend checks and legacy migration fixture in preview/.
- preview/: desktop and phone screenshots. Local test data is created here on first use.
- REVIEW.md: implementation, checks and pending deployment/email requirements. Its 8765 URLs refer to the original project; this Desktop copy uses 8775.
- DEPLOYMENT-HISTORY.md, Caddyfile.https and install-v2.sh: original deployment references.

This preview uses its own local database and writes email previews to files. It does not send email.
Production data, passwords and private server settings are not included.
The original project remains in Documents/DopeHub.net. This Desktop copy has not been deployed.
