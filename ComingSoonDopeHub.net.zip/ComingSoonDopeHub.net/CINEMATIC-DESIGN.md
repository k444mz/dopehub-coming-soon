# DopeHub — Out of the haze

Built 2 October 2026 in the existing Desktop project. Local preview: http://127.0.0.1:8775/

## Art direction

A nocturnal botanical scene moves into a calmer community introduction and a light olive invitation. The typography combines large, tightly spaced Switzer with Gambetta italics. Existing DopeHub branding, UK community context, newsletter/beta preferences, volunteer applications and privacy content are retained.

## Implementation

- `site/index.html`: the new three-section composition plus the existing forms.
- `site/cinematic.css`: responsive design, intro typography, light beam, photographic reveal, orbital graphics, marquee, scroll reveals and modal styling.
- `site/cinematic.js`: custom WebGL fractal fog with pointer clearing, canvas particles, pointer/scroll parallax, image-switching community accordion, motion controls and optional locally synthesized ambience.
- `site/head.js`: pre-paint motion and data-saver preferences.
- `site/app.js`: existing backend integration, unchanged.

Animation rendering is capped at about 30 frames per second, stops outside the hero and while the page is hidden, and has a maximum fog-canvas width of 1280 pixels. All artwork and fonts are served locally. Sound starts only after a click and turns off when the page becomes hidden. Reduced-motion and data-saver modes retain a static visual; a WebGL failure leaves the photographic scene intact. A visible control pauses motion. There is no artificial loading screen or forced wait before accessing the page.

## Original artwork

Both assets were created with the built-in image generation tool, then encoded as WebP for the website. No API-key/CLI fallback was used.

- Desktop: `C:/Users/kams_/Desktop/ComingSoonDopeHub.net/site/media/haze-world.webp` (1672 × 941; approximately 150 KB).
- Portrait: `C:/Users/kams_/Desktop/ComingSoonDopeHub.net/site/media/haze-world-portrait.webp` (768 × 1344; approximately 117 KB).
- Original desktop PNG: `C:/Users/kams_/.codex/generated_images/01a0fb8a-0eff-7c81-a805-dbe371d143ad/exec-45738f32-8a83-45d1-975d-2a4ce85c8c58.png`.
- Original portrait PNG: `C:/Users/kams_/.codex/generated_images/01a0fb8a-0eff-7c81-a805-dbe371d143ad/exec-5809abcd-2a5b-4f39-b1c4-b4adb9578b08.png`.

### Desktop prompt

Use case: stylized-concept
Asset type: cinematic full bleed website hero background, landscape 16:9, 2560x1440.
Create an exceptionally art-directed, photorealistic cinematic botanical environment for an independent British medical cannabis community. Camera at leaf level inside a mysterious dark botanical greenhouse at night, no visible architecture. The image is mainly extremely dark forest green and near black. On the far left and lower right foreground, close large cannabis fan leaves with sharp authentic serrations, luminous fine veins, covered in tiny dew droplets, soft shallow depth of field. Leaves frame a large open central dark negative space intended for huge white typography; central 60 percent must be calm and uncluttered. Behind the centre, a subtle beautiful amber-gold crescent of light / sliver of sunrise suspended in deep atmospheric emerald haze, very faint volumetric light beams cutting diagonally from upper centre toward the lower right, premium cinematic analog 35mm film feel, rich tonal depth, delicately grainy. Gold edge light catches a few leaves, brighter luminous pale green on the right-hand side. Ground fades into fog. Off-centre and natural composition, incredibly tactile and detailed, looks like a frame from a high-budget atmospheric nature film. Dark shadowy foreground layers create immersion and depth. NOT a brightly evenly lit garden. Dark black-green centre with no subjects so white title will be readable. No people, no products, no joints, no smoke apparatus. NO TEXT, NO LOGOS, NO WATERMARKS.

### Portrait edit prompt

The desktop PNG above was supplied as the edit reference.

Use case: precise-object-edit
Asset type: portrait mobile website hero artwork, 9:16 portrait composition.
Recompose the supplied cinematic botanical scene for a tall mobile phone screen. Keep the same beautiful nocturnal black-green palette, authentic dew-covered cannabis fan leaves, photographic film look, amber crescent light and emerald atmospheric haze. This should be the portrait companion image of exactly this scene. Strong framing leaf clusters in the upper left and lower right that remain visible in a narrow portrait crop. A very slender amber crescent light just above centre near the upper right. The centre 65% width from 25% to 72% height must stay open, dark, calm negative space for cream website typography. A few beautifully rim lit leaves crossing the far side edges, but not the text area. Luminous green-gold texture in the upper left and lower right, fog and depth. Highly polished cinematic natural photograph, realistic serrated leaves with fine veins and dew droplets, deep blacks, low key light. No text, no borders, no logos, no people, no products. Create a new tall portrait 1024x1792 image, not a landscape image. Preserve the lighting and material character of the reference, change the framing for portrait mobile.

## Verification

- All 12 existing backend tests passed: `python -m unittest discover -s tests -q`.
- JavaScript syntax checks passed for the new cinematic script and the retained form integration.
- Checked layouts at 320 × 740, 390 × 844, 768 × 1024, 1024 × 768, 1440 × 900 and 1920 × 1080. No document horizontal overflow at these sizes.
- Inspected desktop hero, community section, closing invitation, mobile hero, full mobile layout and signup dialog in the Chromium-based in-app browser.
- Signup validation and successful submission verified with newsletter and beta choices selected. Volunteer role selection and successful application submission verified.
- Privacy dialog, Escape dismissal and focus restoration checked.
- Motion pause/resume, sound on/off, and `?motion=still` checked. Reduced mode hides the canvases, disables continuous CSS motion and keeps every reveal visible.
- All referenced local HTML assets resolve; no duplicate IDs. No browser console errors observed during these checks.
- Preview submissions use fictitious @example.test addresses and local SQLite/email files. No emails were sent externally.

## Preview and backup

Start with `Open Preview.cmd`. The local preview is already running for this review. It can be restarted with that file after a reboot. Production has not been deployed by this change.

Screenshots are in `preview/cinematic-desktop.jpg`, `preview/cinematic-phone.jpg`, `preview/cinematic-phone-full.jpg` and `preview/cinematic-invitation.jpg`.

The previous page, head script and form integration are backed up in `preview/design-before-cinematic/`. Its `editorial.css` and `editorial.js` remain in `site/`. Older design assets are retained but no longer loaded by the new page.

