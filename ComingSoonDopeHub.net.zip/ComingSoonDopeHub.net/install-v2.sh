#!/bin/bash
# Run on dopehub-landing after uploading this folder to /tmp/landing-v2:
#   sudo bash /tmp/landing-v2/install-v2.sh
# Safe to run again for updates: keeps the database, email settings and dashboard password.
set -euo pipefail
SRC=/tmp/landing-v2
STAMP=$(date +%Y%m%d-%H%M%S)
CONF=/etc/dopehub-signup
NEWPW=""

# 1) settings: email + admin secret (created once, never overwritten)
install -d -m 700 $CONF
if [ ! -f $CONF/env ]; then
  sed "s#^ADMIN_SECRET=.*#ADMIN_SECRET=$(openssl rand -hex 32)#" $SRC/server/env.example > $CONF/env
  chmod 600 $CONF/env
fi
if [ ! -f $CONF/admin-password-hash ]; then
  NEWPW=$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)
  caddy hash-password --plaintext "$NEWPW" > $CONF/admin-password-hash
  chmod 600 $CONF/admin-password-hash
fi
ADMIN_SECRET=$(grep '^ADMIN_SECRET=' $CONF/env | cut -d= -f2-)
ADMIN_HASH=$(cat $CONF/admin-password-hash)

# 2) sign-up service
id dopehub-signup >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin dopehub-signup
install -d -m 755 /opt/dopehub-signup
install -m 644 $SRC/server/signup_service.py /opt/dopehub-signup/signup_service.py
install -m 644 $SRC/server/dopehub-signup.service /etc/systemd/system/dopehub-signup.service
install -m 755 $SRC/server/dopehub-signups /usr/local/bin/dopehub-signups
systemctl daemon-reload
systemctl enable dopehub-signup >/dev/null 2>&1
systemctl restart dopehub-signup
sleep 1.5
curl -fsS http://127.0.0.1:8081/api/health >/dev/null && echo "signup service OK"

# 3) site files (keeps a backup of the previous version; keeps founder.jpg if you added one)
if [ -d /var/www/dopehub-landing ]; then cp -a /var/www/dopehub-landing /var/www/dopehub-landing.bak-$STAMP; fi
rm -rf /var/www/dopehub-landing.new && cp -a $SRC/site /var/www/dopehub-landing.new
[ -f /var/www/dopehub-landing/founder.jpg ] && [ ! -f $SRC/site/founder.jpg ] && cp /var/www/dopehub-landing/founder.jpg /var/www/dopehub-landing.new/
chmod -R a+rX /var/www/dopehub-landing.new
rm -rf /var/www/dopehub-landing && mv /var/www/dopehub-landing.new /var/www/dopehub-landing

# 4) Caddy config, validated before reload and rolled back on failure
cp /etc/caddy/Caddyfile /etc/caddy/Caddyfile.bak-$STAMP
python3 - "$ADMIN_HASH" "$ADMIN_SECRET" <<'PY'
import sys
c = open('/tmp/landing-v2/Caddyfile.https').read()
c = c.replace('__ADMIN_HASH__', sys.argv[1]).replace('__ADMIN_SECRET__', sys.argv[2])
open('/etc/caddy/Caddyfile', 'w').write(c)
PY
chmod 640 /etc/caddy/Caddyfile && chgrp caddy /etc/caddy/Caddyfile
if caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile >/dev/null 2>&1; then
  systemctl reload caddy && echo "caddy reloaded"
else
  echo "Caddyfile invalid, rolling back"; cp /etc/caddy/Caddyfile.bak-$STAMP /etc/caddy/Caddyfile; systemctl reload caddy; exit 1
fi

# 5) keep the one-shot HTTPS timer from overwriting this config later
if systemctl list-timers --all 2>/dev/null | grep -q dopehub-enable-https; then
  systemctl disable --now dopehub-enable-https.timer 2>/dev/null || true
  echo "disabled old dopehub-enable-https timer"
fi

echo
echo "DONE. Backups: /var/www/dopehub-landing.bak-$STAMP and /etc/caddy/Caddyfile.bak-$STAMP"
if [ -n "$NEWPW" ]; then
  echo
  echo "=============================================================="
  echo " Dashboard: https://dopehub.net/admin/"
  echo " Username:  kam"
  echo " Password:  $NEWPW"
  echo " Save this password now. It is not stored anywhere in plain text."
  echo "=============================================================="
fi
grep -q '^SMTP_PASS=.\+' $CONF/env || echo "NOTE: emails are queued until you add the no-reply@dopehub.net password (see README)."
