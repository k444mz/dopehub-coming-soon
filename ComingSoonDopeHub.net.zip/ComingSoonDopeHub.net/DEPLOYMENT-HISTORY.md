**Current local upgrade (1 October 2026):** botanical hero and separate newsletter/beta preferences are implemented in this folder, awaiting deployment instruction. See [REVIEW.md](REVIEW.md) for preview, verification, actual email configuration and release steps. The deployment history below describes the previous v4 baseline.

# dopehub.net coming-soon — v4 "the fogged pane" (deployed 28 Sep 2026)

Built by Claude (Fable 5.1). Page source and handover notes: `site/README.txt`. Preview frames: `..\..\coming-soon\fable-preview-*.jpg`.

- `site/` — the page (index.html, head.js, app.js, fog.js, styles.css, fonts/, media/, og.jpg, favicons) + `admin/` dashboard (unchanged from v3).
- `server/` — sign-up service, unchanged from v3 (same files as on the server).
- `Caddyfile.https` — v3 config plus `/media/*`, `/*.svg`, `/*.jpg` in the cached-static matcher.
- `install-v2.sh` — full installer (service + site + Caddy). For page-only updates the lighter route used on 28 Sep was:
  `rsync -az --delete site/ ubuntu@132.226.212.103:/tmp/landing-v4/site/` then on the server swap
  /var/www/dopehub-landing (keeping `.well-known/` and `admin/`), patch the `@static` line in /etc/caddy/Caddyfile,
  `caddy validate` and `systemctl reload caddy`. Backups land in /var/www/dopehub-landing.bak-<stamp> and /etc/caddy/Caddyfile.bak-<stamp>.
- Previous live page (v3) is kept in `..\v3\`.
