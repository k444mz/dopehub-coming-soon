/* DopeHub.net — the fogged pane.
   One WebGL fragment shader over the graded leaf photographs:
   - intro: two lines finger-written into condensation, then a hand-wipe clears the glass
   - ambient: slow re-fog from the edges, pointer trail, warm light sweep, film grain
   - scroll: rack-focus dolly through three shots, then the scene dissolves into --mist
   Zero dependencies. Falls back to CSS when WebGL is missing, on reduced motion, or on Save-Data. */

const doc = document.documentElement;
const reduce = doc.classList.contains("reduce");
const lite = doc.classList.contains("lite");
const stage = document.getElementById("stage");
const canvas = document.getElementById("fog");
const hero = document.querySelector(".hero");
const wrap = document.querySelector(".hero-wrap");
const copy = document.getElementById("hero-copy");
const filmstrip = document.getElementById("filmstrip");
const strip = filmstrip && filmstrip.querySelector(".strip");
const pauseBtn = document.querySelector("[data-pause]");
const skipBtn = document.querySelector("[data-skip-intro]");
const imgs = ["shot-a", "shot-b", "shot-c"].map((id) => document.getElementById(id));

function bail() {
  clearTimeout(window.__fogDeadline);
  window.__fogReady = true;
  doc.classList.add("no-gl", "intro-done");
}

if (reduce || lite) { bail(); }
else init();

function init() {
  const gl = canvas.getContext("webgl", { antialias: false, alpha: false, depth: false, stencil: false, powerPreference: "high-performance", preserveDrawingBuffer: false });
  if (!gl) return bail();

  /* ---------------- shaders ---------------- */
  const VS = `attribute vec2 p; varying vec2 v; void main(){ v = p * .5 + .5; gl_Position = vec4(p, 0., 1.); }`;
  const FS = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 v;
uniform vec2 R;            /* canvas size */
uniform float T;           /* seconds */
uniform float P;           /* scroll progress 0..1 */
uniform float FOG;         /* global fog multiplier */
uniform float GRAIN;       /* grain frame index (frozen when paused) */
uniform float SWEEP;       /* light sweep position, <-1 = off */
uniform vec3 ASP;          /* image aspect (w/h) per shot */
uniform vec3 HAS;          /* 1 if shot texture loaded */
uniform sampler2D A, B, C, MAP, TRAIL;

float hash(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y); }

vec2 cover(vec2 uv, float ia, float scale, vec2 shift){
  float ca = R.x / R.y; vec2 s = uv - .5;
  if (ca > ia) s.y *= ia / ca; else s.x *= ca / ia;
  s /= scale; return s + .5 + shift;
}
vec3 tap(sampler2D t, vec2 uv, float lod){
  if (lod < .05) return texture2D(t, uv).rgb;
  float r = lod * .0035;
  vec3 c = texture2D(t, uv, lod).rgb * .36;
  c += texture2D(t, uv + vec2( r,  r), lod).rgb * .16;
  c += texture2D(t, uv + vec2(-r,  r), lod).rgb * .16;
  c += texture2D(t, uv + vec2( r, -r), lod).rgb * .16;
  c += texture2D(t, uv + vec2(-r, -r), lod).rgb * .16;
  return c;
}
vec3 shot(int i, vec2 uv, float lod){
  if (i == 0) return tap(A, uv, lod);
  if (i == 1) return HAS.y > .5 ? tap(B, uv, lod) : tap(A, uv, lod);
  return HAS.z > .5 ? tap(C, uv, lod) : tap(A, uv, lod);
}
float ss(float a, float b, float x){ return smoothstep(a, b, x); }

void main(){
  vec2 uv = v;
  vec3 mist = vec3(.929, .937, .918);

  /* ---- fog density from the painted maps ---- */
  vec2 muv = vec2(uv.x, 1. - uv.y);
  float base = texture2D(MAP, muv).r;
  float trail = texture2D(TRAIL, muv).r;
  float d = clamp(base - trail, 0., 1.) * FOG;
  /* refraction: condensation bends the view a little */
  vec2 warp = (vec2(noise(uv * 38. + T * .05), noise(uv * 38. + 7.3 - T * .04)) - .5) * .012 * d;
  uv += warp;

  /* ---- the three shots, scroll-linked dolly + rack-focus dissolves ---- */
  float sA = 1.0 + .16 * ss(0., .55, P);
  float sB = 1.06 + .12 * ss(.35, .78, P);
  float sC = 1.10 - .06 * ss(.70, 1., P);
  float mAB = ss(.34, .50, P);
  float mBC = ss(.66, .80, P);
  float fogLod = 5.2 * d;
  vec3 col;
  if (P < .34) {
    col = shot(0, cover(uv, ASP.x, sA, vec2(0.)), fogLod);
  } else if (P < .50) {
    float rack = sin(mAB * 3.14159);
    vec3 a = shot(0, cover(uv, ASP.x, sA, vec2(0.)), fogLod + 5.5 * mAB);
    vec3 b = shot(1, cover(uv, ASP.y, sB, vec2(0.)), fogLod + 5.5 * (1. - mAB) * (1. - .2 * rack));
    col = mix(a, b, mAB);
  } else if (P < .66) {
    col = shot(1, cover(uv, ASP.y, sB, vec2(0.)), fogLod);
  } else if (P < .80) {
    vec3 b = shot(1, cover(uv, ASP.y, sB, vec2(0.)), fogLod + 5.5 * mBC);
    vec3 c = shot(2, cover(uv, ASP.z, sC, vec2(0.)), fogLod + 5.5 * (1. - mBC));
    col = mix(b, c, mBC);
  } else {
    col = shot(2, cover(uv, ASP.z, sC, vec2(0.)), fogLod);
  }

  /* ---- condensation look ---- */
  float frost = noise(uv * R.y * .35 + vec2(3.1, 9.7)) * .5 + noise(uv * R.y * .09) * .5;
  col = mix(col, mist * (.86 + .14 * frost), .50 * d);
  col += (frost - .5) * .10 * d;
  /* darker rim where fog meets clear glass (finite-difference edge on the map) */
  vec2 px = 1.6 / R;
  float ex = texture2D(MAP, muv + vec2(px.x, 0.)).r - texture2D(MAP, muv - vec2(px.x, 0.)).r;
  float ey = texture2D(MAP, muv + vec2(0., px.y)).r - texture2D(MAP, muv - vec2(0., px.y)).r;
  float edge = clamp(length(vec2(ex, ey)) * 1.6, 0., 1.) * FOG;
  col *= 1. - .12 * edge;
  col += .05 * edge * (1. - d);

  /* ---- light sweep (--dawn) ---- */
  if (SWEEP > -1.) {
    float band = uv.x - uv.y * .35 - SWEEP;
    float sw = exp(-band * band * 140.) * .11;
    col += vec3(.902, .722, .541) * sw;
  }

  /* ---- vignette + grain ---- */
  float vig = 1. - .28 * ss(.45, 1.15, length((uv - .5) * vec2(1.15, 1.)) * 1.35);
  col *= vig;
  float g = hash(floor(gl_FragCoord.xy / 1.4) + vec2(GRAIN * 7.17, GRAIN * 3.31)) - .5;
  col += g * .075;

  /* ---- dissolve into the page ---- */
  col = mix(col, mist, ss(.86, 1., P));
  gl_FragColor = vec4(col, 1.);
}`;

  function compile(type, src) {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
    return s;
  }
  let prog;
  try {
    prog = gl.createProgram();
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, VS));
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  } catch (e) { console.warn("fog shader failed", e); return bail(); }
  gl.useProgram(prog);
  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, "p");
  gl.enableVertexAttribArray(loc);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const U = {};
  ["R", "T", "P", "FOG", "GRAIN", "SWEEP", "ASP", "HAS", "A", "B", "C", "MAP", "TRAIL"].forEach((n) => (U[n] = gl.getUniformLocation(prog, n)));
  gl.uniform1i(U.A, 0); gl.uniform1i(U.B, 1); gl.uniform1i(U.C, 2); gl.uniform1i(U.MAP, 3); gl.uniform1i(U.TRAIL, 4);

  /* ---------------- textures ---------------- */
  const asp = [1.6, 1.6, 1.6], has = [0, 0, 0];
  const tex = [0, 1, 2].map(() => { const t = gl.createTexture(); return t; });
  const potW = innerWidth < 700 ? 1024 : 2048, potH = 1024;
  function uploadShot(i) {
    const img = imgs[i];
    if (!img || !img.naturalWidth) return;
    const c = document.createElement("canvas"); c.width = potW; c.height = potH;
    const ctx = c.getContext("2d");
    ctx.drawImage(img, 0, 0, potW, potH);
    asp[i] = img.naturalWidth / img.naturalHeight;
    gl.activeTexture(gl.TEXTURE0 + i);
    gl.bindTexture(gl.TEXTURE_2D, tex[i]);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, c);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    has[i] = 1;
    gl.uniform3f(U.ASP, asp[0], asp[1], asp[2]);
    gl.uniform3f(U.HAS, has[0], has[1], has[2]);
    dirty = true;
  }
  const whenLoaded = (img) => (img.complete && img.naturalWidth ? Promise.resolve() : new Promise((res) => { img.addEventListener("load", res, { once: true }); img.addEventListener("error", res, { once: true }); }));

  /* ---------------- fog maps (2D canvases) ---------------- */
  const MW = 640; let MH = 400;
  const fogC = document.createElement("canvas"), trailC = document.createElement("canvas"), txtC = document.createElement("canvas");
  const fctx = fogC.getContext("2d"), tctx = trailC.getContext("2d"), xctx = txtC.getContext("2d");
  const mapTex = gl.createTexture(), trailTex = gl.createTexture();
  function setupMapTex(t) {
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  }
  gl.activeTexture(gl.TEXTURE3); setupMapTex(mapTex);
  gl.activeTexture(gl.TEXTURE4); setupMapTex(trailTex);
  let mapDirty = true, trailDirty = true, trailEmpty = true;
  function uploadMap(unit, t, c) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
  }

  /* The "clear window": where the headline and form sit. Re-fog never covers it. */
  let refogGrad = null;
  function layoutMaps() {
    const r = stage.getBoundingClientRect();
    MH = Math.max(200, Math.round((MW * r.height) / Math.max(1, r.width)));
    fogC.width = trailC.width = txtC.width = MW;
    fogC.height = trailC.height = txtC.height = MH;
    fctx.fillStyle = "#fff"; fctx.fillRect(0, 0, MW, MH);
    tctx.clearRect(0, 0, MW, MH);
    const cr = copy.getBoundingClientRect();
    const cx = ((cr.left + cr.width * 0.5 - r.left) / r.width) * MW, cy = ((cr.top + cr.height * 0.5 - r.top) / r.height) * MH;
    const rad = Math.max(cr.width, cr.height * 1.4) / r.width * MW * 0.62;
    refogGrad = fctx.createRadialGradient(cx, cy, rad * 0.55, cx, cy, rad * 1.45);
    refogGrad.addColorStop(0, "rgba(255,255,255,0)");
    refogGrad.addColorStop(1, "rgba(255,255,255,1)");
    mapDirty = trailDirty = true;
  }

  /* text lines rendered once, revealed left-to-right like a fingertip */
  const LINES = ["Lots of questions.", "Not many straight answers."];
  function renderLine(i) {
    xctx.clearRect(0, 0, MW, MH);
    const size = Math.min(MW * 0.082, MH * 0.16);
    xctx.font = `500 ${size}px Gambetta, Georgia, serif`;
    xctx.textBaseline = "alphabetic";
    xctx.fillStyle = "#fff"; xctx.strokeStyle = "#fff"; xctx.lineJoin = "round"; xctx.lineWidth = size * 0.11;
    const x = MW * 0.08, y = MH * (0.33 + i * 0.16);
    xctx.strokeText(LINES[i], x, y); xctx.fillText(LINES[i], x, y);
    return { x, w: xctx.measureText(LINES[i]).width, y, size };
  }
  function revealLine(meta, from, to) {
    const x0 = meta.x + meta.w * from - 2, x1 = meta.x + meta.w * to + meta.size * 0.12;
    fctx.save();
    fctx.globalCompositeOperation = "destination-out";
    fctx.beginPath(); fctx.rect(x0, 0, Math.max(0, x1 - x0), MH); fctx.clip();
    fctx.drawImage(txtC, 0, 0);
    fctx.restore();
    mapDirty = true;
  }
  function stamp(ctx, x, y, r, a = 1) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(255,255,255,${a})`); g.addColorStop(0.55, `rgba(255,255,255,${a * 0.7})`); g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill();
  }
  /* hand-wipe: the swept area is one feathered path, rendered small and scaled up (soft in every browser),
     redrawn each frame so the map never accumulates stamp artefacts */
  const wipeY = (s) => MH * (0.52 + 0.045 * Math.sin(s * 3.4 + 0.4));
  const wipeC = document.createElement("canvas"), wctx = wipeC.getContext("2d");
  const WS = 6; /* downscale factor */
  function wipeTo(u) {
    const w = Math.ceil(MW / WS), hh = Math.ceil(MH / WS);
    if (wipeC.width !== w) { wipeC.width = w; wipeC.height = hh; }
    wctx.clearRect(0, 0, w, hh);
    const h = (MH * 0.74) / WS, X = (s) => (MW * (-0.2 + 1.4 * s)) / WS, Y = (s) => wipeY(s) / WS;
    const path = () => {
      wctx.beginPath();
      wctx.moveTo(X(0) - w, Y(0) - h / 2);
      for (let s = 0; s <= u; s += 0.02) wctx.lineTo(X(s), Y(s) - h / 2);
      wctx.arc(X(u), Y(u), h / 2, -Math.PI / 2, Math.PI / 2, false);
      for (let s = u; s >= 0; s -= 0.02) wctx.lineTo(X(s), Y(s) + h / 2);
      wctx.lineTo(X(0) - w, Y(0) + h / 2);
      wctx.closePath();
    };
    wctx.lineJoin = "round"; wctx.lineCap = "round";
    /* feather: wide faint stroke → narrower stronger stroke → solid fill */
    [[9, 0.18], [6, 0.3], [3.5, 0.5], [1.8, 0.8]].forEach(([lw, a]) => { path(); wctx.strokeStyle = `rgba(255,255,255,${a})`; wctx.lineWidth = lw; wctx.stroke(); });
    path(); wctx.fillStyle = "#fff"; wctx.fill();
    fctx.save();
    fctx.globalCompositeOperation = "destination-out";
    fctx.imageSmoothingEnabled = true; fctx.imageSmoothingQuality = "high";
    fctx.drawImage(wipeC, 0, 0, w, hh, 0, 0, MW, MH);
    fctx.restore();
    mapDirty = true;
  }
  const drips = [];
  function seedDrips() {
    drips.length = 0;
    for (let i = 0; i < 7; i++) { const x = MW * (0.08 + Math.random() * 0.84); drips.push({ x, y0: wipeY((x / MW + 0.2) / 1.4) + MH * 0.37 - 2 + Math.random() * 4, len: MH * (0.04 + Math.random() * 0.08), w: 1.6 + Math.random() * 1.8, t0: Math.random() * 0.5, dur: 0.9 + Math.random() * 1.1, done: 0 }); }
  }
  function drawDrips(t) {
    let any = false;
    for (const d of drips) {
      const u = Math.min(1, Math.max(0, (t - d.t0) / d.dur));
      if (u <= d.done) continue; any = true;
      fctx.save(); fctx.globalCompositeOperation = "destination-out"; fctx.fillStyle = "#fff";
      fctx.fillRect(d.x - d.w / 2, d.y0 + d.len * d.done, d.w, d.len * (u - d.done) + 1);
      stamp(fctx, d.x, d.y0 + d.len * u, d.w * 1.6);
      fctx.restore(); d.done = u;
    }
    if (any) mapDirty = true;
  }
  function clearWindow() {
    /* make sure the copy area is clear at the end of the intro */
    const r = stage.getBoundingClientRect(), cr = copy.getBoundingClientRect();
    const cx = ((cr.left + cr.width * 0.5 - r.left) / r.width) * MW, cy = ((cr.top + cr.height * 0.5 - r.top) / r.height) * MH;
    const rad = Math.max(cr.width, cr.height * 1.4) / r.width * MW * 0.8;
    fctx.save(); fctx.globalCompositeOperation = "destination-out";
    stamp(fctx, cx, cy, rad, 1); fctx.restore(); mapDirty = true;
  }

  /* ---------------- state ---------------- */
  let paused = false, visible = true, dirty = true, raf = null;
  let introOn = true, introT0 = 0, introStage = -1, lineMeta = null, lineFrom = 0, wipeU = 0, wipeT = 0;
  let progress = 0, fogMul = 1, sweep = -2, sweepT0 = 0, grainFrame = 0, lastGrain = 0;
  let pointer = null, lastPointer = null;
  const seenIntro = (() => { try { return sessionStorage.getItem("dh-intro") === "1"; } catch (_) { return false; } })();

  function size() {
    const dpr = Math.min(1.5, devicePixelRatio || 1);
    const r = stage.getBoundingClientRect();
    canvas.width = Math.max(2, Math.round(r.width * dpr)); canvas.height = Math.max(2, Math.round(r.height * dpr));
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.uniform2f(U.R, canvas.width, canvas.height);
    dirty = true;
  }

  function endIntro() {
    if (!introOn) return;
    introOn = false; introStage = 9;
    fctx.clearRect(0, 0, MW, MH);
    /* a little fog left in the corners, like a real pane */
    fctx.save(); fctx.globalAlpha = 0.9; fctx.fillStyle = refogGrad; fctx.fillRect(0, 0, MW, MH); fctx.restore();
    fctx.save(); fctx.globalCompositeOperation = "destination-out"; fctx.globalAlpha = 0.55; fctx.fillStyle = "#fff"; fctx.fillRect(0, 0, MW, MH); fctx.restore();
    mapDirty = true; dirty = true;
    doc.classList.add("intro-done");
    skipBtn.hidden = true;
    sweepT0 = performance.now() / 1000 + 1.2;
    try { sessionStorage.setItem("dh-intro", "1"); } catch (_) {}
  }
  function skipIntro() { if (introOn) endIntro(); }

  /* intro timeline (seconds since start) */
  function runIntro(t) {
    if (introStage < 0) { introStage = 0; }
    if (introStage === 0 && t >= 0.5) { introStage = 1; lineMeta = renderLine(0); lineFrom = 0; }
    if (introStage === 1) { const u = Math.min(1, (t - 0.5) / 1.2); revealLine(lineMeta, lineFrom, u); lineFrom = u; if (u >= 1) introStage = 2; }
    if (introStage === 2 && t >= 1.9) { introStage = 3; lineMeta = renderLine(1); lineFrom = 0; }
    if (introStage === 3) { const u = Math.min(1, (t - 1.9) / 1.2); revealLine(lineMeta, lineFrom, u); lineFrom = u; if (u >= 1) introStage = 4; }
    if (introStage === 4 && t >= 3.3) { introStage = 5; wipeU = 0; seedDrips(); wipeT = t; }
    if (introStage === 5) {
      const u = Math.min(1, (t - 3.3) / 0.9), eased = u * u * (3 - 2 * u);
      wipeU = eased; wipeTo(wipeU);
      drawDrips(t - 3.3 - 0.35);
      if (u >= 1) { wipeTo(1); introStage = 6; clearWindow(); }
    }
    if (introStage === 6) { drawDrips(t - 3.3 - 0.35); if (t >= 4.0) { doc.classList.add("intro-done"); skipBtn.hidden = true; introStage = 7; } }
    if (introStage === 7) { drawDrips(t - 3.3 - 0.35); if (t >= 6.0) { introOn = false; introStage = 9; sweepT0 = performance.now() / 1000 + 0.5; try { sessionStorage.setItem("dh-intro", "1"); } catch (_) {} } }
  }

  /* ambient: re-fog from the edges (~20 s), trail decay (~3 s), sweep every ~12 s */
  function runAmbient(now, dt) {
    if (paused) return;
    if (progress < 0.05) {
      fctx.save(); fctx.globalAlpha = Math.min(0.05, dt * 0.05); fctx.fillStyle = refogGrad; fctx.fillRect(0, 0, MW, MH); fctx.restore();
      if (Math.random() < 0.3) mapDirty = true; // no need to upload every frame
    }
    if (!trailEmpty) {
      tctx.save(); tctx.globalCompositeOperation = "destination-out"; tctx.globalAlpha = Math.min(0.2, dt * 0.45); tctx.fillStyle = "#000"; tctx.fillRect(0, 0, MW, MH); tctx.restore();
      trailDirty = true;
    }
    if (pointer && pointer !== lastPointer) {
      const px = pointer.x * MW, py = pointer.y * MH;
      if (lastPointer) { const n = Math.ceil(Math.hypot(px - lastPointer.x * MW, py - lastPointer.y * MH) / 4); for (let i = 1; i <= n; i++) stamp(tctx, lastPointer.x * MW + (px - lastPointer.x * MW) * i / n, lastPointer.y * MH + (py - lastPointer.y * MH) * i / n, MW * 0.045, 0.9); }
      else stamp(tctx, px, py, MW * 0.045, 0.9);
      lastPointer = pointer; trailEmpty = false; trailDirty = true;
    }
    if (now >= sweepT0) { const u = (now - sweepT0) / 2.6; sweep = -0.4 + u * 1.9; if (u >= 1) { sweep = -2; sweepT0 = now + 10 + Math.random() * 4; } }
  }

  /* ---------------- scroll ---------------- */
  function onScroll() {
    const max = wrap.offsetHeight - hero.offsetHeight;
    progress = max > 0 ? Math.min(1, Math.max(0, -wrap.getBoundingClientRect().top / max)) : 0;
    fogMul = 1 - Math.min(1, progress / 0.28);
    const o = 1 - Math.min(1, progress / 0.22);
    copy.style.transition = progress > 0.001 ? "none" : "";
    copy.style.setProperty("--copy-o", o.toFixed(3));
    copy.style.setProperty("--copy-y", (-progress * 160).toFixed(1) + "px");
    copy.style.pointerEvents = o < 0.2 ? "none" : "";
    const ss = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
    hero.style.setProperty("--scrim-o", (1 - ss(0.55, 0.85, progress)).toFixed(3));
    hero.style.setProperty("--bar-o", (1 - ss(0.9, 1, progress)).toFixed(3));
    if (strip) {
      const u = Math.min(1, Math.max(0, (progress - 0.40) / 0.56));
      const e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
      const w = strip.scrollWidth;
      filmstrip.style.setProperty("--strip-x", (innerWidth - e * (innerWidth + w)).toFixed(1) + "px");
      filmstrip.style.setProperty("--strip-o", (Math.min(1, u * 6) * (1 - Math.max(0, (progress - 0.94) / 0.06))).toFixed(3));
    }
    if (introOn && progress > 0.02) skipIntro();
    dirty = true; schedule();
  }

  /* ---------------- frame ---------------- */
  let lastNow = 0, idle = null, frozenT = null;
  function frame(nowMs) {
    raf = null;
    const now = nowMs / 1000, dt = lastNow ? Math.min(0.1, now - lastNow) : 0.016; lastNow = now;
    if (!visible || document.hidden) return;
    if (introOn) runIntro(frozenT != null ? frozenT : now - introT0);
    else runAmbient(now, dt);
    if (!paused && now - lastGrain > 1 / 8) { grainFrame = (grainFrame + 1) % 61; lastGrain = now; }
    if (mapDirty) { uploadMap(3, mapTex, fogC); mapDirty = false; }
    if (trailDirty) { uploadMap(4, trailTex, trailC); trailDirty = false; }
    gl.uniform1f(U.T, now); gl.uniform1f(U.P, progress); gl.uniform1f(U.FOG, introOn ? 1 : fogMul);
    gl.uniform1f(U.GRAIN, grainFrame); gl.uniform1f(U.SWEEP, sweep);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    dirty = false; frames++;
    const busy = introOn || (!paused && (sweep > -2 || !trailEmpty)) || pointer !== lastPointer;
    if (busy) schedule();
    else if (!paused) idle = setTimeout(schedule, 125); /* grain + slow re-fog tick at ~8 fps */
  }
  function schedule() { clearTimeout(idle); idle = null; if (!raf && visible && !document.hidden) raf = requestAnimationFrame(frame); }

  /* ---------------- events ---------------- */
  pauseBtn.addEventListener("click", () => {
    paused = !paused;
    pauseBtn.setAttribute("aria-pressed", String(paused));
    pauseBtn.querySelector("span").textContent = paused ? "Play" : "Pause";
    doc.classList.toggle("paused", paused);
    if (paused) skipIntro(); else { sweepT0 = performance.now() / 1000 + 2; schedule(); }
  });
  skipBtn.addEventListener("click", skipIntro);
  ["keydown", "pointerdown", "wheel", "touchstart"].forEach((ev) => addEventListener(ev, () => { if (introOn && performance.now() / 1000 - introT0 > 0.6) skipIntro(); }, { passive: true }));
  if (matchMedia("(hover: hover) and (pointer: fine)").matches) {
    hero.addEventListener("pointermove", (e) => { if (e.target.closest(".hero-copy")) return; const r = stage.getBoundingClientRect(); pointer = { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; schedule(); }, { passive: true });
    hero.addEventListener("pointerleave", () => { pointer = null; lastPointer = null; });
  }
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; if (visible) schedule(); }, { threshold: 0.01 }).observe(hero);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { lastNow = 0; schedule(); } });
  let rs; addEventListener("resize", () => { clearTimeout(rs); rs = setTimeout(() => { size(); layoutMaps(); if (!introOn) endIntroLayout(); onScroll(); }, 120); });
  function endIntroLayout() { fctx.clearRect(0, 0, MW, MH); fctx.save(); fctx.globalAlpha = 0.4; fctx.fillStyle = refogGrad; fctx.fillRect(0, 0, MW, MH); fctx.restore(); mapDirty = true; }
  addEventListener("scroll", onScroll, { passive: true });

  let frames = 0;
  window.__fogDebug = { fogC, trailC, txtC, get stage() { return introStage; }, get t() { return performance.now() / 1000 - introT0; }, get introOn() { return introOn; }, get frames() { return frames; },
    jump(t) { frozenT = t; introT0 = performance.now() / 1000 - t; lastNow = 0; schedule(); }, thaw() { frozenT = null; schedule(); } };

  /* ---------------- go ---------------- */
  clearTimeout(window.__fogDeadline);
  window.__fogReady = true;
  size(); layoutMaps();
  const fontsReady = document.fonts ? Promise.race([document.fonts.load("500 40px Gambetta").catch(() => {}), new Promise((r) => setTimeout(r, 900))]) : Promise.resolve();
  Promise.all([whenLoaded(imgs[0]), fontsReady]).then(() => {
    uploadShot(0);
    gl.uniform3f(U.ASP, asp[0], asp[1], asp[2]); gl.uniform3f(U.HAS, 1, 0, 0);
    introT0 = performance.now() / 1000;
    if (seenIntro || doc.classList.contains("intro-done")) endIntro();
    else skipBtn.hidden = false;
    onScroll(); schedule();
    /* the other two shots can arrive later: they're only needed on scroll */
    const later = () => { whenLoaded(imgs[1]).then(() => { uploadShot(1); schedule(); }); whenLoaded(imgs[2]).then(() => { uploadShot(2); schedule(); }); };
    if ("requestIdleCallback" in window) requestIdleCallback(later, { timeout: 2500 }); else setTimeout(later, 800);
  });
}
