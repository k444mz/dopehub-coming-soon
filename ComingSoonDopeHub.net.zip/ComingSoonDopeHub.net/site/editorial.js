/* A photographic opening that settles into its real position. No libraries or tracking. */
(() => {
  'use strict';
  const root = document.documentElement;
  const panel = document.querySelector('.opening');
  const target = document.querySelector('.image-window');
  const skip = document.querySelector('.skip-opening');
  const replay = document.querySelector('.replay');
  const pause = document.querySelector('.motion-toggle');
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const forcedStill = new URLSearchParams(location.search).get('motion') === 'still';
  const still = () => preference.matches || forcedStill || root.classList.contains('lite');
  let animations = [], timers = [], running = false, paused = false, generation = 0;

  function finish() {
    generation++;
    timers.forEach(clearTimeout); timers = [];
    animations.forEach(a => a.cancel()); animations = [];
    root.classList.remove('intro-preparing', 'intro-playing', 'intro-revealing');
    skip.hidden = true;
    running = false;
  }
  function later(fn, time) { timers.push(setTimeout(fn, time)); }
  function animate(element, frames, options) {
    const animation = element.animate(frames, { fill: 'both', ...options });
    animations.push(animation);
    return animation;
  }
  async function start() {
    const preparing = root.classList.contains('intro-preparing');
    finish();
    if (still() || !panel.animate) return;
    if (preparing) root.classList.add('intro-preparing');
    const current = generation;
    // Never hold up the page for an unavailable image or font.
    await Promise.race([
      Promise.all([panel.querySelector('img').decode().catch(() => {}), document.fonts.ready]),
      new Promise(resolve => setTimeout(resolve, 700))
    ]);
    if (current !== generation) return;
    if (still() || document.hidden || !panel.querySelector('img').naturalWidth) return finish();
    const rect = target.getBoundingClientRect();
    // On narrow screens the artwork follows the headline: reveal in place.
    const mobile = innerWidth <= 650;
    running = true;
    paused = false;
    root.classList.remove('paused');
    pause.setAttribute('aria-pressed', 'false');
    pause.setAttribute('aria-label', 'Pause motion'); pause.textContent = 'Ⅱ';
    root.classList.remove('intro-preparing');
    root.classList.add('intro-playing');
    skip.hidden = false;
    animate(panel.querySelector('.opening-title'), [
      { opacity: 0, transform: 'translateY(12px)', offset: 0 },
      { opacity: 1, transform: 'translateY(0)', offset: .22 },
      { opacity: 1, transform: 'translateY(0)', offset: .67 },
      { opacity: 0, transform: 'translateY(-15px)', offset: 1 }
    ], { duration: 1250, easing: 'ease' });
    animate(panel.querySelector('.opening-rule'), [{ transform: 'scaleX(.15)' }, { transform: 'scaleX(2.5)' }], { duration: 1100, easing: 'cubic-bezier(.22,1,.36,1)' });
    animate(panel.querySelector('.opening-shade'), [{ opacity: .83 }, { opacity: 0 }], { duration: 1800, delay: 550, easing: 'ease' });
    animate(panel.querySelector('img'), [{ transform: 'scale(1.13)' }, { transform: 'scale(1.065)' }], { duration: 2600, easing: 'cubic-bezier(.22,1,.36,1)' });
    if (mobile) {
      animate(panel, [{ clipPath: 'inset(0 0 0 0 round 0px)' }, { clipPath: 'inset(0 0 100% 0 round 0px)' }], { duration: 1250, delay: 1050, easing: 'cubic-bezier(.76,0,.24,1)' });
    } else {
      animate(panel, [
        { left: '0px', top: '0px', width: `${innerWidth}px`, height: `${innerHeight}px`, borderRadius: '0% 0% 0px 0px' },
        { left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px`, borderRadius: '48% 48% 3px 3px' }
      ], { duration: 1700, delay: 900, easing: 'cubic-bezier(.76,0,.24,1)' });
    }
    later(() => root.classList.add('intro-revealing'), 1350);
    later(finish, 2700);
  }
  skip.addEventListener('click', () => { finish(); replay.focus({ preventScroll: true }); });
  replay.addEventListener('click', () => {
    finish();
    window.scrollTo({ top: 0, behavior: 'instant' });
    // Let the deliberate scroll settle before enabling scroll-to-skip again.
    requestAnimationFrame(() => requestAnimationFrame(start));
  });
  pause.addEventListener('click', () => {
    finish(); paused = !paused; root.classList.toggle('paused', paused);
    pause.setAttribute('aria-pressed', String(paused));
    pause.setAttribute('aria-label', paused ? 'Resume motion' : 'Pause motion');
    pause.textContent = paused ? '▷' : 'Ⅱ';
  });
  document.addEventListener('pointerdown', event => { if (running && !event.target.closest('.skip-opening,.replay')) finish(); });
  document.addEventListener('focusin', event => { if (running && !event.target.closest('.skip-opening')) finish(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && running) finish(); });
  window.addEventListener('resize', () => { if (running) finish(); }, { passive: true });
  window.addEventListener('scroll', () => { if (running) finish(); }, { passive: true });
  document.addEventListener('visibilitychange', () => { if (document.hidden) finish(); });
  preference.addEventListener('change', () => { root.classList.toggle('reduce', preference.matches || forcedStill); finish(); });
  // Confirmation links get straight to their result, without the opening.
  const params = new URLSearchParams(location.search);
  if (!params.has('confirm') && !params.has('unsubscribe')) start();
})();
