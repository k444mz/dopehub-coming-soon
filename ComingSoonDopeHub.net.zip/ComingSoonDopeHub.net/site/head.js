/* Motion preferences are resolved before paint; content never waits for JavaScript. */
(() => {
  const root = document.documentElement;
  const params = new URLSearchParams(location.search);
  const connection = navigator.connection || {};
  root.classList.add('js');
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || params.get('motion') === 'still') root.classList.add('reduce');
  if (connection.saveData || /(^|[^\d])2g/.test(connection.effectiveType || '')) root.classList.add('lite');
})();
