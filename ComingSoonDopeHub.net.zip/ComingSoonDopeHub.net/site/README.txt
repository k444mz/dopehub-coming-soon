CURRENT SOURCE — 1 October 2026
The botanical upgrade replaces the fog runtime. See ../REVIEW.md for current instructions. The notes below describe the previous design and are historical.

DopeHub.net — coming-soon page ("the fogged pane")
Built 28 Sep 2026 by Claude (Fable 5.1) from DOPEHUB-ASTRA-BRIEF.md + ASTRA-PROMPT.md.

WHAT'S IN site/
  head.js             Tiny synchronous script: reduced-motion / Save-Data flags + the 1.5 s intro deadline (external because CSP is script-src 'self').
  index.html          The page. Hero (sign-up form in it), Join the team + FAQ band, slim footer, dialogs (apply, privacy, unsubscribe).
  styles.css          Palette + type tokens from the brief. Gambetta (headlines) and Switzer (everything else), self-hosted.
  app.js              Forms, survey, apply dialog, confirm/unsubscribe banners, cookie-free page hit. Carried over from
                      current-app.js so it still matches signup_service.py (/api/subscribe, survey, apply, confirm, unsubscribe, hit).
                      Preview mode is kept: off dopehub.net / 132.226.212.103 / localhost the forms fake success.
                      hello@ fallbacks changed to contact@dopehub.net.
  fog.js              The WebGL hero (module, deferred, zero dependencies). Fog written by fingertip, hand-wipe, pointer trail,
                      slow re-fog from the edges, warm light sweep, 8 fps film grain, scroll-linked rack-focus dolly through
                      three shots, dissolve into --mist. Falls back to CSS when WebGL is missing, on prefers-reduced-motion,
                      and on Save-Data / 2G.
  fonts/              Gambetta-Variable.woff2, Switzer-Variable.woff2 (+ Fontshare licences).
  media/              Graded photos, WebP + AVIF. leaf-a/b/c = hero shots (desktop 1000/1600 w, mobile 800 w 2:3).
                      strip-1..6 = the community filmstrip (900 w). One colour grade across everything (tools/grade.py in the
                      build folder: lift blacks, greens toward verdigris/slate, warm highlights, softer contrast). Originals untouched.
  og.jpg              1200x630 Open Graph image, composed in code (leaf-a + wordmark + headline in Gambetta).
  favicon.svg / .png / apple-touch-icon.png   "D" monogram, Gambetta glyph outline, mist on --iron.

BUDGETS (measured)
  Hero images: desktop 3 x 1600 WebP = 254 KB (AVIF smaller). Mobile 3 x 800 WebP = 185 KB. Only leaf-a is needed before
  first paint; b and c load after idle. Filmstrip 6 x ~40 KB, fetched at low priority.
  JS: fog.js 8.2 KB gz + app.js 3.7 KB gz. CSS 4.9 KB gz. Fonts 79 KB. OG 105 KB.

DEPLOY
  Same as before: static files behind Caddy, /api/ proxied to the sign-up service. Copy site/* into landing-deploy/v4/site
  (or wherever install-v2.sh points), keep the existing admin/ and .well-known/ in place. All asset paths are absolute (/fonts/…),
  so the page must be served from the domain root; opening index.html from disk won't load fonts or images.
  Suggested Caddy headers: Cache-Control immutable for /fonts, /media (rename files if you replace them).

WHAT I DECIDED WHERE THE BRIEF AND PROMPT DISAGREED
  - Concept: your "wipe the fog off the glass" idea, on the real leaf photographs, followed by the prompt's cinematic
    scroll exit (rack-focus dolly through leaf-a → leaf-b → leaf-c, then the community filmstrip). Letterbox bars open on load.
  - The colour grade is baked into the exported files rather than done live in the shader: identical look everywhere
    (hero, filmstrip, OG image), no cost on phones, and the originals in IMAGES FOR DOPEHUB stay untouched. Grain, fog,
    the light sweep and the dolly are live in WebGL.
  - Sign-up: email + "Get updates" in the hero; "I'm…", the consent box and the three promises unfold when the field is
    focused; the survey replaces the form in place. Nav "Get updates" scrolls up and focuses the field.
  - "A community, not a shop" appears as a small museum label under the filmstrip (not on any photo, no names or quotes).
  - The intro plays once per browser session. That uses sessionStorage("dh-intro"), which is a functional flag, not
    tracking (it clears when the tab closes, nothing is sent anywhere). Delete the two sessionStorage lines in fog.js
    if you'd rather have no storage at all; the intro then plays on every load (still skippable).
  - Alternative headlines from the brief are not used; the h1 is "Medical cannabis, talked about properly."

IMAGES: WHAT WAS USED AND WHAT WAS DROPPED (UK compliance)
  Used   cannabis-02 (leaf-a, hero opener), cannabis-01 (leaf-b), cannabis-12 (leaf-c, single leaf on pale ground).
         community-06, -01, -11, -12, -07, social-09 (filmstrip, atmosphere only).
  Dropped cannabis-04, -09, -13: each shows a flowering top with visible pistils (CAP 12 / "no flowers or buds").
         cannabis-07, -14: a hand in the cannabis shot (no people next to any cannabis image).
         All other files in the pack were simply not needed.
  Credits (Unsplash licence, no attribution required):
    cannabis-01 Matthew Brodeur · cannabis-02 Rick Proctor · cannabis-12 Elsa Olofsson · community-01 Priscilla Du Preez ·
    community-06 Dorota Trzaska · community-07 Felix Rostig · community-11 LinkedIn Sales Solutions ·
    community-12 alex starnes · social-09 June Aye. Full links in IMAGES FOR DOPEHUB/coming-soon-stock/CREDITS.txt.

UK COMPLIANCE CHECKLIST (all checked)
  [x] Community, not a medicine: no products, strains, clinics, pharmacies, prices or "get a prescription" wording anywhere.
  [x] No health claims. "Not medical advice" in the hero small print and the footer.
  [x] No flowers/buds/products/bottles/droppers/packaging/shopfronts/text in any image. No crosses, white coats, before/after.
  [x] No children; no people next to cannabis imagery; nobody presented as a member or quoted.
  [x] 18+ on both forms and in the footer. Consent boxes unticked. Double opt-in handled by the server.
  [x] UK GDPR/PECR: privacy notice (word for word from the previous page) reachable from both forms and the footer.
      No cookies, no third-party scripts/fonts/analytics, so no cookie banner. Page hit is cookie-free and skips DNT/GPC.
  [x] Accessibility: one h1, skip link, labels outside inputs, visible focus (verdigris on light, dawn on dark), errors via
      aria-live, native <dialog> (focus trap + Esc), canvas aria-hidden, visible Pause control, full reduced-motion path
      (static graded hero, no intro, no scroll animation, no filmstrip).
  [x] Forms/API unchanged from current-app.js.

TESTED
  Chromium (software WebGL) at 1440x900 and 390x844: intro frames at 0.3/1.1/1.7/2.6/3.6/3.9/4.3/7 s, pointer trail,
  scroll positions 12–100 %, dialogs, sign-up → survey, reduced motion, WebGL disabled. Please also try it on your own
  phone (iOS Safari address-bar behaviour with svh) and a real GPU; the intro is timed, so it will feel much smoother than
  the test frames suggest.

KNOWN LIMITS / THINGS YOU MAY WANT TO CHANGE
  - No Lighthouse run in this environment. The budgets above are well inside the brief's targets.
  - The filmstrip is hidden under prefers-reduced-motion (it is scroll-driven atmosphere only).
  - The "Join the team" ghost button sits next to "Get updates" in the hero; drop it if you want the form alone.
  - window.__fogDebug in fog.js exposes jump()/thaw() for testing the intro frame by frame. Harmless; remove if you like.
