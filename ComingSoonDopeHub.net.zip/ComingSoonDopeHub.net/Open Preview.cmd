@echo off
cd /d "%~dp0"
echo Open http://127.0.0.1:8775/ in your browser after the preview starts.
echo Keep this window open while viewing the website.
python tools\preview.py
pause
