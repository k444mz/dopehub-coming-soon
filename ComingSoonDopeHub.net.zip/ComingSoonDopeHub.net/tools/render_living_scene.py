"""Render silent, seamless botanical cinemagraphs from ImageGen clean plates.

The still plates are generated edits; this script authors their video motion.
Requires NumPy, Pillow and ffmpeg. Run with the bundled Python runtime.
"""
from pathlib import Path
import argparse
import math
import subprocess
import time as clock

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
DURATION = 12
FPS = 30
TAU = math.tau

SCENES = {
    'landscape': {
        'size': (1600, 900), 'sun': (.684, .196),
        # Clean leaf tips in normalized source-image coordinates.
        'tips': [(.171, .513, 4, 1.5, 5.8), (.352, .425, 6, 3.1, 5.3), (.386, .224, 4, 3.0, 4.2)],
        'glints': [(.240,.143),(.118,.090),(.274,.180),(.180,.204),(.319,.141),(.876,.625),(.892,.345),(.915,.752)],
        'gravity': 780, 'scale': 1,
    },
    'portrait': {
        'size': (720, 1260), 'sun': (.793, .126),
        'tips': [(.127, .284, 4, 1.5, 4.0), (.374, .211, 6, 3.1, 3.8), (.463, .135, 4, 3.0, 3.2)],
        'glints': [(.235,.053),(.309,.093),(.154,.134),(.260,.162),(.900,.607),(.818,.781)],
        'gravity': 730, 'scale': .8,
    },
}

def smoothstep(a, b, value):
    x = np.clip((value - a) / (b - a), 0, 1)
    return x*x*(3-2*x)


class Scene:
    def __init__(self, name, preview_scale=1):
        self.name = name
        self.config = SCENES[name]
        w, h = self.config['size']
        self.w, self.h = int(w*preview_scale)//2*2, int(h*preview_scale)//2*2
        self.pixel_scale = preview_scale
        self.image = Image.open(ROOT / f'tools/motion/{name}-plate.png').convert('RGB').resize((self.w, self.h), Image.Resampling.LANCZOS)
        self.xx, self.yy = np.meshgrid(np.linspace(0,1,self.w,dtype=np.float32), np.linspace(0,1,self.h,dtype=np.float32))
        sx, sy = self.config['sun']
        dx = (self.xx-sx)*self.w/self.h
        dy = self.yy-sy
        self.angle = np.arctan2(dy,dx)
        self.radius = np.sqrt(dx*dx+dy*dy)
        # Foreground foliage blocks scattered sunlight. The masks have soft edges.
        left = np.exp(-((self.xx-.13)/.22)**4-((self.yy-.20)/(.32 if name=='landscape' else .15))**4)
        right = np.exp(-((self.xx-.94)/.23)**4-((self.yy-.80)/.34)**4)
        self.occlusion = (1-left*.91)*(1-right*.71)
        self.radial = np.exp(-self.radius*2.3)*smoothstep(.009,.06,self.radius)
        self.sun_halo = np.exp(-self.radius*self.radius/.0065)
        self.sun_bloom = np.exp(-self.radius*self.radius/.00034)
        self.haze = np.exp(-((self.yy-.69)/.23)**2) * self.occlusion
        self.base = np.asarray(self.image,dtype=np.float32)/255
        # A smooth mesh gives the foliage only a very small breeze. No camera pan.
        self.mesh = []
        nx, ny = 20, 16
        for j in range(ny):
            for i in range(nx):
                x0,x1 = round(i*self.w/nx), round((i+1)*self.w/nx)
                y0,y1 = round(j*self.h/ny), round((j+1)*self.h/ny)
                self.mesh.append((x0,y0,x1,y1))

    def displacement(self, x, y, phase):
        u, v = x/self.w, y/self.h
        left = math.exp(-((u-.17)/.26)**4-((v-.22)/(.34 if self.name=='landscape' else .19))**4)
        right = math.exp(-((u-.92)/.3)**4-((v-.80)/.37)**4)
        flex = min(1, (u+v)*1.5)
        dx = (left*flex*(math.sin(phase)*1.7+math.sin(phase*2)*.35) + right*math.sin(phase+.8)*1.1)*self.pixel_scale
        dy = (left*flex*math.sin(phase+.4)*1.35 + right*math.sin(phase*2+.2)*.7)*self.pixel_scale
        return dx,dy

    def moving_plate(self, phase):
        mesh=[]
        for x0,y0,x1,y1 in self.mesh:
            quad=[]
            for x,y in [(x0,y0),(x0,y1),(x1,y1),(x1,y0)]:
                dx,dy=self.displacement(x,y,phase)
                quad.extend((x-dx,y-dy))
            mesh.append(((x0,y0,x1,y1),tuple(quad)))
        return np.asarray(self.image.transform((self.w,self.h),Image.Transform.MESH,mesh,Image.Resampling.BILINEAR),dtype=np.float32)/255

    def glint(self, frame, x, y, intensity, radius=6):
        r=max(2,int(radius*self.pixel_scale))
        x0,y0=max(0,int(x)-r),max(0,int(y)-r)
        x1,y1=min(self.w,int(x)+r+1),min(self.h,int(y)+r+1)
        if x1<=x0 or y1<=y0:return
        yy,xx=np.mgrid[y0:y1,x0:x1].astype(np.float32)
        d=((xx-x)**2+(yy-y)**2)/(max(1,self.pixel_scale)*1.2)**2
        light=(np.exp(-d*.5)*.43+np.exp(-d*.07)*.055)*intensity
        patch=frame[y0:y1,x0:x1]
        patch[:]=1-(1-patch)*(1-light[...,None]*np.array([1,.86,.53],dtype=np.float32))

    def droplet(self, frame, x, y, rx, ry, opacity=1, hanging=False):
        if opacity<=0 or rx<.4:return
        x0,y0=max(0,math.floor(x-rx-2)),max(0,math.floor(y-ry-2))
        x1,y1=min(self.w,math.ceil(x+rx+3)),min(self.h,math.ceil(y+ry+3))
        if x1<=x0 or y1<=y0:return
        yy,xx=np.mgrid[y0:y1,x0:x1].astype(np.float32)
        ny=(yy-y)/ry
        taper=(.77+.20*np.clip(ny,-1,1)) if hanging else 1
        nx=(xx-x)/(rx*taper)
        distance=np.sqrt(nx*nx+ny*ny)
        mask=(1-smoothstep(.82,1.06,distance))*opacity
        # Refracted colour is sampled from the real scene, with Fresnel edges and
        # a small sun-facing highlight. Falling beads are transparent, not white dots.
        sample_x=np.clip((x-(xx-x)*.45+rx*.3).astype(int),0,self.w-1)
        sample_y=np.clip((y-(yy-y)*.65-ry*.35).astype(int),0,self.h-1)
        refracted=frame[sample_y,sample_x]*.72
        edge=np.exp(-((distance-.84)/.095)**2)
        sunlight=np.clip(nx*.7-ny*.6,.0,1)
        rim=edge*(.07+.65*sunlight)
        caustic=np.exp(-((nx+.10)**2/.14+(ny-.67)**2/.015))*.73
        sparkle=np.exp(-((nx-.40)**2/.045+(ny+.40)**2/.055))*.82
        gold=np.array([1,.86,.50],dtype=np.float32)
        drop=refracted + (rim+caustic)[...,None]*gold + sparkle[...,None]*np.array([1,.97,.80],dtype=np.float32)
        patch=frame[y0:y1,x0:x1]
        patch[:]=patch*(1-mask[...,None])+np.clip(drop,0,1)*mask[...,None]

    def water(self, frame, seconds, phase):
        for u,v,period,offset,max_radius in self.config['tips']:
            tipx,tipy=u*self.w,v*self.h
            dx,dy=self.displacement(tipx,tipy,phase)
            tipx+=dx;tipy+=dy
            age=(seconds+offset)%period
            release=period*.62
            radius=max_radius*self.pixel_scale
            # Surface-tension growth, followed by a short necking phase.
            if age<release:
                growth=age/release
                r=radius*(.12+.88*growth**.74)
                stretch=float(smoothstep(.87,1,growth))*.60
                ry=r*(1.18+stretch)
                self.droplet(frame,tipx+math.sin(phase*2)*r*.08,tipy+ry*.76,r,ry,hanging=True)
            else:
                falling=age-release
                g=self.config['gravity']*self.pixel_scale
                speed=24*self.pixel_scale+g*falling
                x=tipx+falling*(5*self.pixel_scale)+math.sin(phase)*falling*2
                y=tipy+radius*1.35+24*self.pixel_scale*falling+.5*g*falling*falling
                fade=1-float(smoothstep(.82,1.01,y/self.h))
                rx=radius*(.92+.04*math.sin(falling*32))
                ry=radius*(1+.3*math.exp(-falling*7)) + min(speed*.005,7*self.pixel_scale)
                self.droplet(frame,x,y,rx,ry,fade)
                # A much smaller satellite bead detaches from the thinning neck.
                if falling>.12:
                    s=falling-.12
                    self.droplet(frame,tipx-1.5*self.pixel_scale+s*2,tipy+radius+g*s*s*.43,radius*.29,radius*.42+speed*.0015,fade*.75)

    def frame(self, seconds):
        phase=seconds/DURATION*TAU
        frame=self.moving_plate(phase)
        # Clouds slowly open around the light source. Every oscillator repeats
        # at exactly twelve seconds, including the three droplet periods.
        opening=.48+.52*(.5+.5*math.sin(phase-.7))
        rayfield=np.zeros((self.h,self.w),np.float32)
        for i,(angle,spread,strength) in enumerate([(1.34,.035,.40),(1.68,.055,.65),(1.97,.045,.78),(2.18,.027,.55),(2.40,.055,.33)]):
            sway=math.sin(phase+i*.83)*.026
            stripe=np.exp(-((self.angle-angle-sway)/spread)**2)
            rolling=.72+.28*np.sin(self.radius*17-phase*2+i)
            rayfield+=stripe*strength*rolling
        rays=rayfield*self.radial*self.occlusion*(.045+.12*opening)
        sun=self.sun_halo*(.045+.15*opening)+self.sun_bloom*(.09+.28*opening)
        mist_pattern=.5+.25*np.sin(self.xx*18+self.yy*8-phase)+.25*np.sin(self.xx*9-self.yy*17+phase*2)
        mist=self.haze*mist_pattern*.019
        illumination=rays+sun+mist
        gold=np.array([1,.76,.37],dtype=np.float32)
        frame=1-(1-frame)*(1-illumination[...,None]*gold)
        # The warm exposure changes most strongly in existing lit leaf edges.
        lightmask=np.clip((self.base.max(axis=2)-.21)*1.7,0,1)
        frame*=1+lightmask[...,None]*opening*.08
        for i,(u,v) in enumerate(self.config['glints']):
            x,y=u*self.w,v*self.h
            dx,dy=self.displacement(x,y,phase)
            catch=max(0,math.sin(phase+i*.94))**18
            self.glint(frame,x+dx,y+dy,catch*.75)
        self.water(frame,seconds,phase)
        return np.clip(frame*255,0,255).astype(np.uint8)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('scene',choices=SCENES)
    parser.add_argument('--scale',type=float,default=1)
    parser.add_argument('--frames-only',action='store_true')
    args=parser.parse_args()
    scene=Scene(args.scene,args.scale)
    out=ROOT/'site/media'/f'living-{args.scene}.mp4'
    preview=ROOT/'preview/motion';preview.mkdir(exist_ok=True)
    if args.frames_only:
        for t in [0, .8, 1.15, 1.35, 1.65, 2.5, 5, 8, 11.9666667]:
            Image.fromarray(scene.frame(t)).save(preview/f'{args.scene}-{t:.2f}.jpg',quality=94)
        return
    command=['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{scene.w}x{scene.h}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','slow','-crf','20','-pix_fmt','yuv420p','-profile:v','high','-level','4.1','-movflags','+faststart','-g',str(FPS*2),str(out)]
    encoder=subprocess.Popen(command,stdin=subprocess.PIPE)
    started=clock.monotonic()
    try:
        for i in range(DURATION*FPS):
            frame=scene.frame(i/FPS)
            encoder.stdin.write(frame.tobytes())
            if i%60==0:
                print(f'{args.scene}: {i}/{DURATION*FPS} frames, {clock.monotonic()-started:.1f}s',flush=True)
            if i in [0,40,65,150]:Image.fromarray(frame).save(preview/f'{args.scene}-frame-{i}.jpg',quality=93)
    finally:
        encoder.stdin.close()
    if encoder.wait():raise RuntimeError('Video encoding failed')
    # The poster uses the same authored first frame, so there is no load jump.
    Image.fromarray(scene.frame(0)).save(ROOT/'site/media'/f'living-{args.scene}-poster.webp',quality=89,method=6)
    print(f'Saved {out.name}: {out.stat().st_size/1024/1024:.2f} MB in {clock.monotonic()-started:.1f}s',flush=True)


if __name__=='__main__':main()
