/* Set motion preferences before the first paint. */
(() => {
  const root = document.documentElement;
  root.classList.add('motion-ready');
  const connection = navigator.connection || {};
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || new URLSearchParams(location.search).get('motion') === 'still') root.classList.add('reduce');
  if (connection.saveData || /(^|[^\d])2g/.test(connection.effectiveType || '')) root.classList.add('lite');
})();
