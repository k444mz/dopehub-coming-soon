
/* Native botanical mesh. HTML artwork remains the no-WebGL/no-motion fallback. */
(() => {
  'use strict';
  const root=document.documentElement, hero=document.querySelector('.hero'), scene=document.querySelector('.scene');
  const replay=document.querySelector('.replay'), pause=document.querySelector('.motion-toggle');
  const preference=matchMedia('(prefers-reduced-motion: reduce)');
  const forcedStill=new URLSearchParams(location.search).get('motion')==='still';
  const isStill=()=>preference.matches||forcedStill||root.classList.contains('lite');
  let opening=false, paused=false, visible=true, elapsed=0, breeze=0, previous=0, frame=0, renderer;
  const duration=2850;
  function finish(){
    opening=false; elapsed=duration; root.classList.remove('opening'); root.classList.add('settled');
    replay.innerHTML='<span aria-hidden="true">↻</span> Replay opening'; renderer?.draw(elapsed,breeze,true);
  }
  function start(){
    if(isStill()) return finish();
    elapsed=0; opening=true; paused=false; root.classList.remove('settled','opening','paused');
    pause.setAttribute('aria-pressed','false'); pause.innerHTML='<span aria-hidden="true">Ⅱ</span> Pause motion';
    void hero.offsetWidth; root.classList.add('opening'); replay.innerHTML='<span aria-hidden="true">↗</span> Skip opening'; wake();
  }
  function tick(now){
    frame=0; const delta=previous?now-previous:0; previous=now;
    if(!paused&&visible&&!document.hidden&&!isStill()){
      breeze+=delta/1000; if(opening){elapsed+=delta;if(elapsed>=duration)finish();} renderer?.draw(elapsed,breeze);
    }
    if(!paused&&visible&&!document.hidden&&!isStill())frame=requestAnimationFrame(tick);
  }
  function wake(){previous=0;if(!frame&&!isStill()&&visible&&!document.hidden&&!paused)frame=requestAnimationFrame(tick);}
  replay.addEventListener('click',()=>opening?finish():start());
  pause.addEventListener('click',()=>{
    paused=!paused;root.classList.toggle('paused',paused);pause.setAttribute('aria-pressed',String(paused));
    pause.innerHTML=paused?'<span aria-hidden="true">▷</span> Resume motion':'<span aria-hidden="true">Ⅱ</span> Pause motion';
    if(paused){cancelAnimationFrame(frame);frame=0;}else wake();
  });
  hero.querySelector('.hero-copy').addEventListener('focusin',finish);
  hero.querySelector('.hero-copy').addEventListener('pointerdown',finish);
  preference.addEventListener('change',()=>{
    root.classList.toggle('reduce',preference.matches||forcedStill);finish();
    if(isStill()){cancelAnimationFrame(frame);frame=0;}else wake();
  });
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else wake();});
  new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(!visible){cancelAnimationFrame(frame);frame=0;}else wake();},{threshold:0}).observe(hero);

  async function createRenderer(){
    if(isStill())return;
    const elements=[...scene.querySelectorAll('.branch')], images=[...new Set(elements.map(e=>e.querySelector('img').src))];
    // Decode the existing DOM images: no duplicate downloads on uncached previews.
    const decoded=await Promise.all(images.map(async src=>{
      const image=elements.map(e=>e.querySelector('img')).find(image=>image.src===src);
      await image.decode(); return image;
    }));
    if(isStill())return;
    const canvas=document.createElement('canvas');canvas.className='botanical-canvas';canvas.setAttribute('aria-hidden','true');
    const gl=canvas.getContext('webgl',{alpha:true,antialias:false,premultipliedAlpha:true,depth:false,stencil:false,powerPreference:'low-power'});
    if(!gl)return;
    function shader(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error('Botanical shader unavailable');return s;}
    const vertex=shader(gl.VERTEX_SHADER,`
      attribute vec2 a_uv;
      uniform vec2 u_resolution,u_origin;
      uniform float u_size,u_angle,u_bend,u_time,u_phase,u_mirror,u_motion;
      varying vec2 v_uv;
      void main(){
        float h=1.0-a_uv.y;
        vec2 p=vec2((a_uv.x-.5)*u_size,-h*u_size);
        // Quadratic flex holds the base still while the growing tip responds.
        p.x+=u_bend*h*h;
        float leaf=sin(a_uv.x*18.0+a_uv.y*11.0+u_phase+u_time*.75);
        p.x+=leaf*pow(h,1.7)*2.8*u_motion;
        p.y+=sin(u_time*.62+u_phase+a_uv.x*13.0)*h*h*1.4*u_motion;
        float c=cos(u_angle),s=sin(u_angle);
        vec2 position=u_origin+vec2(c*p.x-s*p.y,s*p.x+c*p.y);
        gl_Position=vec4(position.x/u_resolution.x*2.0-1.0,1.0-position.y/u_resolution.y*2.0,0,1);
        v_uv=vec2(u_mirror<0.0?1.0-a_uv.x:a_uv.x,a_uv.y);
      }`);
    const fragment=shader(gl.FRAGMENT_SHADER,`
      precision mediump float;
      uniform sampler2D u_image;
      uniform float u_light;
      varying vec2 v_uv;
      void main(){
        vec4 leaf=texture2D(u_image,v_uv);
        float luma=dot(leaf.rgb,vec3(.2126,.7152,.0722));
        vec3 colour=mix(vec3(luma),leaf.rgb,.72)*u_light;
        gl_FragColor=vec4(colour,leaf.a);
      }`);
    const program=gl.createProgram();gl.attachShader(program,vertex);gl.attachShader(program,fragment);gl.linkProgram(program);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('Botanical renderer unavailable');gl.useProgram(program);
    const uniforms={};for(const name of ['resolution','origin','size','angle','bend','time','phase','mirror','motion','image','light'])uniforms[name]=gl.getUniformLocation(program,'u_'+name);
    const vertices=[],indices=[],cols=24,rows=32;
    for(let y=0;y<=rows;y++)for(let x=0;x<=cols;x++)vertices.push(x/cols,y/rows);
    for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){const p=y*(cols+1)+x;indices.push(p,p+1,p+cols+1,p+1,p+cols+2,p+cols+1);}
    const mesh=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,mesh);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.STATIC_DRAW);
    const uv=gl.getAttribLocation(program,'a_uv');gl.enableVertexAttribArray(uv);gl.vertexAttribPointer(uv,2,gl.FLOAT,false,0,0);
    const index=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,index);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(indices),gl.STATIC_DRAW);
    gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);
    const textures=decoded.map(image=>{
      const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);return texture;
    });
    let width,height,layers=[],lastPaint=-1;
    function resize(){
      width=hero.clientWidth;height=hero.clientHeight;const dpr=Math.min(devicePixelRatio||1,1.5);
      canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);gl.viewport(0,0,canvas.width,canvas.height);
      layers=elements.map((element,i)=>{
        const css=getComputedStyle(element),number=(name,fallback=0)=>parseFloat(css.getPropertyValue(name))||fallback;
        const size=parseFloat(css.width),bottom=parseFloat(css.bottom),top=parseFloat(css.top);
        return {i,size,x:parseFloat(css.left)+size/2,y:Number.isFinite(bottom)?height-bottom:top+size,
          open:number('--open')*Math.PI/180,closed:number('--closed')*Math.PI/180,delay:number('--delay')*1000,
          duration:number('--duration',2.6)*1000,mirror:number('--mirror',1),depth:number('--depth',1),
          texture:textures[images.indexOf(element.querySelector('img').src)],light:[.94,.89,.57,.55,1.02,.96,.65,.61][i]};
      }).sort((a,b)=>a.depth-b.depth||a.i-b.i);
      lastPaint=-1;draw(elapsed,breeze,true);
    }
    function draw(ms,time,force=false){
      // The barely perceptible resting movement needs only 30 fps.
      if(!force&&ms>=duration&&time-lastPaint<1/30&&lastPaint>=0)return;lastPaint=time;
      gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);gl.uniform2f(uniforms.resolution,width,height);
      gl.uniform1f(uniforms.time,time);gl.uniform1f(uniforms.motion,isStill()?0:width<650?.4:1);
      for(const layer of layers){
        const t=Math.max(0,Math.min(1,(ms-layer.delay)/layer.duration)),release=1-Math.pow(1-t,3),direction=layer.i%2===0?1:-1;
        const sway=isStill()?0:Math.sin(time*(.36+layer.i*.018)+layer.i*1.7)*.003*(width<650?.45:1);
        const settle=Math.sin(t*Math.PI*2)*Math.sin(t*Math.PI)*.014*direction;
        gl.uniform2f(uniforms.origin,layer.x,layer.y);gl.uniform1f(uniforms.size,layer.size);
        gl.uniform1f(uniforms.angle,layer.closed+(layer.open-layer.closed)*release+settle+sway*release);
        gl.uniform1f(uniforms.bend,direction*layer.size*.065*(1-release)+(isStill()?0:Math.sin(time*.51+layer.i)*layer.size*.004)*release);
        gl.uniform1f(uniforms.phase,layer.i*2.31);gl.uniform1f(uniforms.mirror,layer.mirror);gl.uniform1f(uniforms.light,layer.light);
        gl.bindTexture(gl.TEXTURE_2D,layer.texture);gl.uniform1i(uniforms.image,0);gl.drawElements(gl.TRIANGLES,indices.length,gl.UNSIGNED_SHORT,0);
      }
    }
    const observer=new ResizeObserver(resize);
    canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();root.classList.remove('mesh-ready');renderer=undefined;canvas.remove();observer.disconnect();});
    scene.append(canvas);resize();observer.observe(hero);root.classList.add('mesh-ready');return {draw};
  }
  start();createRenderer().then(value=>{renderer=value;}).catch(()=>root.classList.remove('mesh-ready'));
})();
