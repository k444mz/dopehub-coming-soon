# Editorial redesign · 2 October 2026

Short landing page with an ivory/forest palette, oversized serif headline,
arched botanical photograph, compact volunteer band and native signup dialogs.
Existing form fields, consent choices, privacy notice and API endpoints retained.

Opening: 2.7-second photograph-to-arch transition on desktop; a shorter vertical
reveal on phones. Skip, replay and pause controls. Reduced-motion and Save-Data
preferences disable the opening and ambient motion. Confirmation/unsubscribe
links bypass the opening. No new third-party dependencies or remote assets.

Preview at http://127.0.0.1:8775/ using Open Preview.cmd.
This is a local redesign; it has not been deployed.

Browser checks: Chromium at 320, 390, 768, 1440 and 1920 pixels; no horizontal
overflow. Opening, replay/pause, reduced motion, signup validation, role selection,
privacy dialog and keyboard dismissal checked. Signup and volunteer success
states and outgoing request fields also checked with isolated mocked responses;
these checks do not send email or write production data. No browser console errors.

Previous index and scripts are preserved in design-before-editorial.
Previous CSS files and all original artwork remain available in site/.
