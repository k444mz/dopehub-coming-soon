/* A small, dependency-free atmospheric renderer. The page also works without it. */
(() => {
  'use strict';
  const root = document.documentElement;
  const hero = document.querySelector('.hero');
  const motion = document.querySelector('.motion-toggle');
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const forcedStill = new URLSearchParams(location.search).get('motion') === 'still';
  let paused = false, visible = true, frame = 0, last = 0, time = 0;
  let pointer = { x: 0, y: 0 }, eased = { x: 0, y: 0 };
  const still = () => paused || preference.matches || forcedStill || root.classList.contains('lite');

  // Native scrolling and one small observer keep the rest of the page independent of the scene.
  if ('IntersectionObserver' in window) {
    const reveals = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        reveals.unobserve(entry.target);
      }
    }), { threshold: .08 });
    document.querySelectorAll('.reveal').forEach(el => reveals.observe(el));
    root.classList.add('observing');
    new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; restart(); }).observe(hero);
  }

  let scrollFrame = 0;
  function updateScroll() {
    scrollFrame = 0;
    const position = window.scrollY;
    const progress = Math.min(1, position / hero.offsetHeight);
    root.style.setProperty('--scroll', progress.toFixed(4));
    const total = document.documentElement.scrollHeight - innerHeight;
    document.querySelector('.scroll-progress').style.transform = `scaleX(${total > 0 ? position / total : 0})`;
  }
  window.addEventListener('scroll', () => { if (!scrollFrame) scrollFrame = requestAnimationFrame(updateScroll); }, { passive: true });
  hero.addEventListener('pointermove', event => {
    if (event.pointerType === 'touch' || still()) return;
    const rect = hero.getBoundingClientRect();
    pointer.x = (event.clientX - rect.left) / rect.width * 2 - 1;
    pointer.y = (event.clientY - rect.top) / rect.height * 2 - 1;
  }, { passive: true });
  hero.addEventListener('pointerleave', () => { pointer.x = 0; pointer.y = 0; });

  const canvas = document.querySelector('#atmosphere');
  let gl = null, program = null, uniforms = null, contextLost = false;
  function createAtmosphere() {
    if (gl || still()) return;
    try {
      gl = canvas.getContext('webgl', { alpha: true, antialias: false, depth: false, powerPreference: 'low-power', premultipliedAlpha: false });
      if (!gl) return;
      const vertex = `attribute vec2 position; varying vec2 uv; void main(){uv=position*.5+.5;gl_Position=vec4(position,0.,1.);}`;
      const fragment = `
        precision mediump float;
        varying vec2 uv;
        uniform vec2 resolution;
        uniform vec2 pointer;
        uniform float time;
        float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
        float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
        float fbm(vec2 p){float v=0.;float a=.5;mat2 r=mat2(.8,-.6,.6,.8);for(int i=0;i<5;i++){v+=a*noise(p);p=r*p*2.03+1.7;a*=.5;}return v;}
        void main(){
          float aspect=resolution.x/resolution.y;
          vec2 p=uv*vec2(aspect,1.)*2.8;
          float t=time*.035;
          vec2 q=vec2(fbm(p+vec2(t,-t*.4)),fbm(p+vec2(4.7-t*.6,1.3+t*.4)));
          float f=fbm(p+q*2.7+vec2(-t*.7,t*.3));
          float mist=smoothstep(.26,.81,f);
          float low=1.-smoothstep(.1,.84,uv.y);
          float distanceToPointer=length((uv-pointer)*vec2(aspect,1.));
          float clear=.3+.7*smoothstep(.02,.42,distanceToPointer);
          float beam=exp(-abs(uv.x-.68-(uv.y-.65)*.38)*7.);
          vec3 color=mix(vec3(.15,.27,.18),vec3(.60,.56,.27),beam*.65);
          float alpha=mist*(.24+low*.60)*clear;
          gl_FragColor=vec4(color,alpha);
        }`;
      const compile = (type, source) => {
        const shader = gl.createShader(type); gl.shaderSource(shader, source); gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) { gl.deleteShader(shader); throw new Error('Atmosphere unavailable'); }
        return shader;
      };
      const vs = compile(gl.VERTEX_SHADER, vertex), fs = compile(gl.FRAGMENT_SHADER, fragment);
      program = gl.createProgram(); gl.attachShader(program, vs); gl.attachShader(program, fs); gl.linkProgram(program);
      gl.deleteShader(vs); gl.deleteShader(fs);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('Atmosphere unavailable');
      gl.useProgram(program);
      const buffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, -1,1, 1,-1, 1,1]), gl.STATIC_DRAW);
      const location = gl.getAttribLocation(program, 'position');
      gl.enableVertexAttribArray(location); gl.vertexAttribPointer(location, 2, gl.FLOAT, false, 0, 0);
      uniforms = Object.fromEntries(['resolution','pointer','time'].map(key => [key,gl.getUniformLocation(program,key)]));
      resize();
    } catch (_) { program = null; canvas.hidden = true; }
  }
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); contextLost = true; canvas.hidden = true; });
  canvas.addEventListener('webglcontextrestored', () => { contextLost = false; gl = null; program = null; canvas.hidden = false; createAtmosphere(); });

  const dust = document.querySelector('#motes');
  const ctx = dust.getContext('2d');
  let width = 1, height = 1;
  // Seeded particles avoid distracting random jumps when resizing.
  let seed = 83;
  const random = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const particles = Array.from({ length: innerWidth < 650 ? 28 : 56 }, () => ({ x: random(), y: random(), size: .5 + random() * 1.5, speed: .5 + random(), phase: random() * Math.PI * 2 }));
  function resize() {
    width = hero.clientWidth; height = hero.clientHeight;
    const ratio = Math.min(1, 1280 / width);
    canvas.width = Math.round(width * ratio); canvas.height = Math.round(height * ratio);
    if (gl && program && !contextLost) gl.viewport(0, 0, canvas.width, canvas.height);
    const dpr = Math.min(devicePixelRatio || 1, 1.5);
    dust.width = Math.round(width * dpr); dust.height = Math.round(height * dpr);
    if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    updateScroll();
  }
  function paintDust() {
    if (!ctx) return;
    ctx.clearRect(0, 0, width, height);
    for (const p of particles) {
      const x = (p.x * width + Math.sin(time * .11 + p.phase) * 25 + eased.x * p.size * 7 + width) % width;
      const y = (p.y * height - time * p.speed * 4 + height * 100) % height;
      const alpha = (.15 + .3 * (.5 + .5 * Math.sin(time * .5 + p.phase))) * (p.size / 2);
      ctx.beginPath(); ctx.arc(x, y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(219,231,161,${alpha})`; ctx.fill();
    }
  }
  function render(stamp) {
    frame = 0;
    if (still() || !visible || document.hidden) { last = 0; return; }
    frame = requestAnimationFrame(render);
    if (last && stamp - last < 32) return; // Capped at 30fps: atmosphere, not a battery benchmark.
    const dt = last ? Math.min((stamp - last) / 1000, .08) : .033;
    last = stamp; time += dt;
    eased.x += (pointer.x - eased.x) * .065;
    eased.y += (pointer.y - eased.y) * .065;
    root.style.setProperty('--px', eased.x.toFixed(4));
    root.style.setProperty('--py', eased.y.toFixed(4));
    if (gl && program && !contextLost) {
      gl.useProgram(program); gl.uniform2f(uniforms.resolution, canvas.width, canvas.height);
      gl.uniform2f(uniforms.pointer, (eased.x + 1) / 2, 1 - (eased.y + 1) / 2);
      gl.uniform1f(uniforms.time, time); gl.drawArrays(gl.TRIANGLES, 0, 6);
    }
    paintDust();
  }
  function restart() {
    if (frame) cancelAnimationFrame(frame);
    frame = 0; last = 0;
    if (!still() && visible && !document.hidden) { createAtmosphere(); frame = requestAnimationFrame(render); }
  }
  function syncMotion() {
    const reduced = preference.matches || forcedStill || root.classList.contains('lite');
    root.classList.toggle('reduce', preference.matches || forcedStill);
    root.classList.toggle('paused', paused);
    motion.setAttribute('aria-pressed', String(still()));
    motion.setAttribute('aria-label', reduced ? 'Motion reduced by your device or preview settings' : paused ? 'Resume motion' : 'Pause motion');
    motion.disabled = reduced;
    motion.querySelector('[data-motion-label]').textContent = reduced ? 'MOTION REDUCED' : paused ? 'MOTION OFF' : 'MOTION ON';
    motion.querySelector('.motion-symbol').textContent = still() ? '▷' : 'Ⅱ';
    restart();
  }
  motion.addEventListener('click', () => { paused = !paused; syncMotion(); });
  preference.addEventListener('change', syncMotion);
  window.addEventListener('resize', resize, { passive: true });

  // The image follows the selected community principle.
  const codes = ['SHARED EXPERIENCE', 'A CLEARER PERSPECTIVE', 'ROOM TO GROW'];
  document.querySelectorAll('[data-principle]').forEach(button => button.addEventListener('click', () => {
    const index = Number(button.dataset.principle);
    document.querySelectorAll('[data-principle]').forEach(other => {
      const active = other === button;
      other.setAttribute('aria-expanded', String(active));
      other.closest('.principle').classList.toggle('is-active', active);
      document.getElementById(other.getAttribute('aria-controls')).hidden = !active;
      other.querySelector('.principle-plus').textContent = active ? '−' : '+';
    });
    document.querySelectorAll('[data-specimen]').forEach(image => image.classList.toggle('is-active', Number(image.dataset.specimen) === index));
    document.querySelector('.specimen-code').textContent = `FIG. 0${index + 1} — ${codes[index]}`;
  }));

  document.querySelectorAll('.magnetic').forEach(button => {
    button.addEventListener('pointermove', event => {
      if (event.pointerType !== 'mouse' || still()) return;
      const rect = button.getBoundingClientRect();
      button.style.translate = `${(event.clientX - rect.left - rect.width / 2) * .065}px ${(event.clientY - rect.top - rect.height / 2) * .13}px`;
    });
    button.addEventListener('pointerleave', () => { button.style.translate = '0px 0px'; });
  });

  // Optional, locally synthesized ambience. No audio loads or plays until requested.
  const soundButton = document.querySelector('.sound-toggle');
  let audio = null, gain = null, soundOn = false;
  async function toggleSound() {
    soundButton.disabled = true;
    try {
      if (!audio) {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio) throw new Error('No audio');
        audio = new Audio(); gain = audio.createGain(); gain.gain.value = 0; gain.connect(audio.destination);
        [110, 164.81, 220.32, 277.18].forEach((frequency, index) => {
          const oscillator = audio.createOscillator(), voice = audio.createGain();
          oscillator.type = 'sine'; oscillator.frequency.value = frequency;
          voice.gain.value = index === 0 ? .28 : .09;
          oscillator.connect(voice); voice.connect(gain); oscillator.start();
        });
        const buffer = audio.createBuffer(1, audio.sampleRate * 5, audio.sampleRate);
        const channel = buffer.getChannelData(0);
        for (let i = 0; i < channel.length; i++) channel[i] = Math.random() * 2 - 1;
        const breeze = audio.createBufferSource(), filter = audio.createBiquadFilter(), breezeGain = audio.createGain();
        breeze.buffer = buffer; breeze.loop = true; filter.type = 'lowpass'; filter.frequency.value = 380;
        breezeGain.gain.value = .2; breeze.connect(filter); filter.connect(breezeGain); breezeGain.connect(gain); breeze.start();
      }
      await audio.resume(); soundOn = !soundOn;
      gain.gain.cancelScheduledValues(audio.currentTime);
      gain.gain.setTargetAtTime(soundOn ? .11 : 0, audio.currentTime, .5);
      soundButton.setAttribute('aria-pressed', String(soundOn));
      soundButton.setAttribute('aria-label', soundOn ? 'Mute ambient sound' : 'Enable ambient sound');
      soundButton.querySelector('[data-sound-label]').textContent = soundOn ? 'SOUND ON' : 'SOUND OFF';
    } catch (_) {
      soundOn = false;
      soundButton.querySelector('[data-sound-label]').textContent = 'SOUND UNAVAILABLE';
    } finally { soundButton.disabled = false; }
  }
  soundButton.addEventListener('click', toggleSound);
  document.addEventListener('visibilitychange', () => {
    restart();
    if (audio && document.hidden) {
      gain.gain.setValueAtTime(0, audio.currentTime);
      audio.suspend().catch(() => {});
      soundOn = false;
      soundButton.setAttribute('aria-pressed', 'false');
      soundButton.setAttribute('aria-label', 'Enable ambient sound');
      soundButton.querySelector('[data-sound-label]').textContent = 'SOUND OFF';
    }
  });
  resize(); syncMotion();
})();
