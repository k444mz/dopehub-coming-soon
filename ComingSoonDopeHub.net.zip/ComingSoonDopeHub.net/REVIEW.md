# Botanical landing-page upgrade — local review, 1 October 2026

This upgrade is prepared locally. It has not been published. Wait for Kam's deployment instruction.

## Preview

Run `python tools/preview.py` from this folder. Website: http://127.0.0.1:8765/.
Email preview: http://127.0.0.1:8765/__mail/.
Still composition: http://127.0.0.1:8765/?motion=still.

The preview binds only to 127.0.0.1, forces file-only email delivery and uses its own
`preview/local/signups.db`. It never reads the production database or sends messages.
Use reserved test addresses, for example `member@example.test`.

## Visual implementation — 2 October 2026

The short landing page now contains the animated hero, a compact volunteer section
and minimal footer. Existing signup, application, confirmation and privacy paths
remain connected. This is a finished local review build; publishing still requires
Kam's instruction.

- Preserved DopeHub logo. Six generated transparent branch assets, eight placements,
  approximately 485 KB of WebP artwork. No external stock imagery or video service.
- A native WebGL mesh curves stems from fixed bases and allows leaf tips to respond
  independently. Each plant has its own release, settling phase and slow sway.
  The roughly 2.85-second opening uses no animation library. The original CSS branch
  animation is retained when WebGL is unavailable. The renderer reuses decoded DOM images to avoid duplicate downloads and can join the current animation state after loading.
- The GPU renderer applies restrained colour and depth shading, caps pixel density
  at 1.5, draws resting motion at no more than 30 fps and stops rendering while
  paused, off-screen or in a background tab. Context loss returns to HTML artwork.
- Reduced motion and data-saving mode use static final artwork without creating a
  renderer. The static review URL is `?motion=still`. A no-JavaScript view retains
  the final HTML plant composition.
- The form is usable throughout. Touching or focusing the central content completes
  the reveal immediately. Skip/replay and pause/resume controls remain accessible.
- Larger labelled fields, independently selectable preference cards and confirmation
  copy tailored to the choices submitted. No text or controls are baked into images.
- The cream volunteer section offers compact contribution areas, with detailed
  application fields in the existing accessible dialog. Grouped areas let applicants
  choose the appropriate specific role rather than assigning it for them.
- The live demo and local main application were inspected as references. The main
  application is not redesigned.
## Signup and email behaviour

New newsletter and beta preferences are independent and initially inactive. A
confirmation activates exactly the choices in that request. Changes to an existing
address also require inbox confirmation, so an unauthenticated submission cannot
change someone else's consent. Duplicate confirmations are throttled to 15 minutes;
new confirmation requests expire after seven days. Old confirmation tokens remain
supported for existing records.

The migration is additive. Existing combined signups retain their original
newsletter/beta preferences, tokens, survey responses and confirmation state.
Applications and their dashboard workflow remain in the same database.

Newsletter unsubscribe preserves beta; beta cancellation preserves newsletter.
Old combined unsubscribe links still remove the original signup. Withdrawing the
last active preference removes the signup. Pending marketing is checked against
current consent immediately before delivery.

Applications are saved as before, notify contact@dopehub.net and now queue an
acknowledgement to the applicant. They never create newsletter subscriptions.
All automated messages use no-reply@dopehub.net and Reply-To contact@dopehub.net.
Sender names are DopeHub or DopeHub Newsletter.

`tools/mail_campaign.py` prepares newsletters, launch messages and individual beta
invitations. It previews by default and rolls back queued rows; only an explicit
`--queue` commits messages for the existing mail worker. Campaign IDs prevent the
same campaign being queued twice for a subscriber. Newsletter recipients must have
confirmed newsletter consent; beta recipients must have confirmed beta consent.

JSON input fields:

- Newsletter/launch: `campaign_id`, `kind` (`newsletter` or `launch`), `subject`, `body`.
- Beta invitation: `campaign_id`, `kind` (`beta_invite`), `email`, `access_url`.

No real beta access destination was found in the current configuration. Invitation
sending refuses to queue until `BETA_INVITE_ORIGIN` is configured and the operator
supplies a real approved HTTPS invitation URL on that origin. There are no placeholder
access links in public signup or production email templates. Waiting-list confirmation
does not grant access.

## Verification

- Focused Python integration tests cover independent consent, confirmation, duplicate
  requests, old-schema migration, legacy links, both unsubscribe scopes, RFC 8058,
  application storage and notifications, SMTP/relay headers, invitation gating,
  campaign idempotency, expiry, validation, origin protection and rate limits.
- Browser checks: desktop 1440px, tablet 768px, phones 390px and 320px; no horizontal
  page overflow. Opening-frame form availability, final plant clearance, pause,
  independent breeze and static fallback were inspected. Keyboard focus, privacy
  dialog opening/Escape, beta-only signup, confirmation and application success were
  exercised through the real local service.
- JavaScript syntax and Python compilation checks pass. Test records are synthetic.
- Live inbox delivery has not been tested in this task; no approved real test
  recipient was supplied. Production subscribers received no test mail.

## Actual deployed configuration, verified read-only

The landing host is 132.226.212.103. Live index.html and signup_service.py match the
v4 baseline hashes; the older root README reference to v3 is stale.

- Site: `/var/www/dopehub-landing`; Caddy: `/etc/caddy/Caddyfile`.
- Public `/api/*` and protected `/admin/api/*` proxy to 127.0.0.1:8081.
- Service: `dopehub-signup`; code: `/opt/dopehub-signup/signup_service.py`.
- SQLite: `/var/lib/dopehub-signup/signups.db`; environment: `/etc/dopehub-signup/env`.
- Transport is `relay`, through `https://demo.dopehub.net/relay/email`, not the
  historical SMTP configuration that is still present in the environment.
- Oracle confirms no-reply@dopehub.net is ACTIVE and dopehub.net is an ACTIVE email
  domain. The gateway allows that sender. DNS SPF includes Oracle's European relay,
  DKIM selector `dopehub-lon-202609` resolves to Oracle, and DMARC is published.
- Reply-To and application alert recipient are already contact@dopehub.net.
- systemd reported the unit on disk differs from its loaded state; include
  `systemctl daemon-reload` in the approved deployment.

## Deployment after explicit instruction

Do not use the old `install-v2.sh` blindly: it hard-codes `/tmp/landing-v2` and performs
a whole-directory replacement. This upgrade needs both the site and service update.

1. Stage only reviewed release files in a new folder on the landing host. Do not
   upload `preview/`, `tests/`, test mail, local databases or temporary tooling.
2. Back up the live site, code and config. Use SQLite's backup API for a consistent
   database snapshot, including WAL state; preserve ownership and permissions.
3. Briefly stop the signup service for the change. Preserve the live environment,
   database, administrator credentials, `admin/` and `.well-known/` directories.
4. Overlay the reviewed public site files and new media/fonts on a staged copy of
   the current site. Install the revised service and `tools/mail_campaign.py` if the
   operator wants campaign tooling. Keep originals for rollback.
5. Keep the current Caddy routes and authentication. No Caddy change is required for
   the new assets (the existing `/media/*` matcher covers them). The script/style
   query versions invalidate old browser caches.
6. Reload systemd units, start the service, and verify `/api/health`, the public page,
   protected dashboard and additive migration. Inspect counts only; do not export
   subscriber data into the release bundle.
7. With an explicitly approved test address, verify live confirmation and application
   emails and headers. Send no test campaign to subscribers. Configure real beta
   invitation destinations only when access is approved and ready.
8. Retain the backup. A rollback of the old service should be paired with the saved
   database snapshot if needed; assess any new signups first to avoid data loss.

## Superseding hero prototype checks

The new prototype was reviewed at 1440×1000, 390×844 and 320×760. No horizontal overflow. Opening and final frames inspected; independent transforms, skip/replay, pause/resume, automatic completion on form interaction and the motion-free state verified. Keyboard tab from newsletter to beta has a visible focus ring. Local newsletter-only submission returned validation and then the confirmation success state; messages remained in the file-only preview. Existing application dialog opens and closes with Escape. Both front-end scripts passed syntax checks; browser error log empty during form verification. Previous full backend tests above still describe the unchanged backend.

The earlier prototype review is superseded by the completed short-page refinement described above. Publishing still requires explicit instruction.

## Refined page verification — 2 October 2026

- Desktop mesh rendering confirmed in the browser; no JavaScript or WebGL errors.
- Opening, pause/resume, form-interaction completion and static fallback checked.
- Layout checked at 1440, 768, 390 and 320 pixels with no horizontal overflow.
- Newsletter-only form validation and successful local submission checked, including
  the correct newsletter-specific confirmation copy. No real email was sent.
- Grouped team role selection, privacy dialog and Escape dismissal verified.
- All 12 existing backend integration tests passed after the refinement. Front-end
  scripts pass JavaScript syntax checks. Backend code and production data unchanged.
- Screenshots are in `preview/refined-desktop.jpg` and `preview/refined-phone.jpg`.
- Remaining release requirements: approved real beta access origin/link, an approved
  recipient for live inbox delivery testing if required, and deployment instruction.